# basiccalculator
![C/C++ CI](https://github.com/99002785/Mini_Calci/workflows/C/C++%20CI/badge.svg)
![cppcheck-action](https://github.com/99002785/Mini_Calci/workflows/cppcheck-action/badge.svg)
[![Codacy Badge](https://app.codacy.com/project/badge/Grade/f167b49a564a4aa29ff3eaf6cf27eadb)](https://www.codacy.com/gh/99002785/Mini_Calci/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=99002785/Mini_Calci&amp;utm_campaign=Badge_Grade)
![cppcheck-action](https://github.com/99002781/basiccalculator/workflows/cppcheck-action/badge.svg)

