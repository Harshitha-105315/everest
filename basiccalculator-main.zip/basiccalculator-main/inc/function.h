#ifdef__FUNCTION_H__
#define__FUNCTION_H__

#include<stdio.h>

#include<math.h>
int addition(int num1,int num2);
int subtraction(int num1,int num2);
int division(int num1,int num2);
int multiplication(int num1,int num2);
int modulus(int input1,int input2);
void power(int num,int pow);
int factorial(int num);

#endif
