package com.sportsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
