![CI](https://github.com/99002761/2010MYSSPS02_Spring_with_MongoDB__sportsApplication/workflows/CI/badge.svg)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/d12dd254578c46518590db6c008fd3cf)](https://app.codacy.com/gh/99002761/2010MYSSPS02_Spring_with_MongoDB__sportsApplication?utm_source=github.com&utm_medium=referral&utm_content=99002761/2010MYSSPS02_Spring_with_MongoDB__sportsApplication&utm_campaign=Badge_Grade)
#MongoDB-sportsApplication



Features:

-get details of Stadium,city,state and specality game for the stadium

-update the details

-delete the details

Technologies:

-Java

-MongoDB

-PostMan Collaboration Platform
