# 2010MYSSPS02_WebDev_LibraryManagement

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/7f77a07d07ab4a348b9db543fef86d98)](https://app.codacy.com/gh/99002783/2010MYSSPS02_WebDev_LibraryManagement?utm_source=github.com&utm_medium=referral&utm_content=99002783/2010MYSSPS02_WebDev_LibraryManagement&utm_campaign=Badge_Grade)

![CI](https://github.com/99002783/2010MYSSPS02_WebDev_LibraryManagement/workflows/CI/badge.svg)
![Jekyll site CI](https://github.com/99002783/2010MYSSPS02_WebDev_LibraryManagement/workflows/Jekyll%20site%20CI/badge.svg)
