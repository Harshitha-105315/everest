package com.lts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentMongoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentMongoapiApplication.class, args);
	}

}
